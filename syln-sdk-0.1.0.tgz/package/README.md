# @syln/sdk 0.1.0

Server-side JavaScript/TypeScript, Node 22+. Zero runtime dependencies; ESM and CommonJS with declarations.
This version is distributed as a tarball, not yet published to npm.

```sh
npm install ./syln-sdk-0.1.0.tgz
```

```js
import { Syln, SylnError } from '@syln/sdk';
// CommonJS: const { Syln, SylnError } = require('@syln/sdk');
const client = new Syln({ token: process.env.SYLN_TOKEN ?? '' });
const { data, meta, requestId, rateLimit } = await client.catalog({ has_media: true, limit: 10 });
const episodes = await client.episodes(data[0].id);
// Only issue playback when requested by the user; this consumes quota.
const play = await client.play(data[0].id, episodes.data[0].ep, { res: 720 });
console.log(play.data.url, play.data.expires_in, play.data.resolution);
```

Check for empty catalog/episode arrays before indexing them in your application.

```js
try {
  for await (const title of client.iterateCatalog({ limit: 100 }, { maxPages: 2 })) {
    console.log(title.id);
    break; // no next page is requested
  }
} catch (error) {
  if (error instanceof SylnError) console.error(error.status, error.requestId, error.retryAfter);
  throw error;
}
```

Methods: `platforms(options?)`, `languages(platform?, options?)`, `catalog(params?, options?)`,
`search(q, params?, options?)`, `title(id, {lang}?, options?)`, `episodes(id, options?)`,
`play(id, ep, {res, lang}?, options?)`. Each `options` accepts `signal` and `timeoutMs`.
Catalog parameters: `platform`, `lang`, `has_media`, `feed`, `page` (1..10000), `limit` (1..100).

Constructor: `{token, baseURL?, timeoutMs?, maxResponseBytes?, fetch?}`. Default whole-request timeout 15000 ms, including response body; 4 MiB response cap. Reuse the client. No cache, automatic retries, or prefetch. `meta.count` is page length. Rate-limit `reset` is seconds until reset, not epoch. Missing headers remain undefined; zero is preserved.

Keep tokens in server environment variables. Never expose them in a browser bundle. Custom fetch implementations must honor AbortSignal, no-store, and redirect policies.
